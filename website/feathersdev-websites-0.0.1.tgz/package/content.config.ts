import { defineCollection, defineContentConfig } from '@nuxt/content'
import { z } from 'zod'

// Products
export const productSchema = z.object({
  title: z.string(),
  published: z.boolean(),
  highlight: z.boolean(),
  shortName: z.string(),
  description: z.string(),
  longDescription: z.string(),
  menuDescription: z.string(),
  slug: z.string(),
  icon: z.string(),
  logo: z.string(),
  link: z.string(),
  birdImage: z.string(),
  planetImage: z.string(),
  iconImage: z.string().optional(),
  iconSize: z.number().optional(),
})
export type Product = z.infer<typeof productSchema>

export default defineContentConfig({
  collections: {
    products: defineCollection({
      type: 'data',
      source: 'products/**/*.yaml',
      schema: productSchema,
    }),
    sharedPages: defineCollection({
      type: 'page',
      source: 'pages/**/*.md',
    }),
  },
})
