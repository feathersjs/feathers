<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'

const props = defineProps<{
  /** Array of Nuxt Content collection names to search. If not provided, auto-detects from route. */
  collections?: string[]
  /** Display name for the search (e.g., "Feathers Docs"). If not provided, auto-generates. */
  searchLabel?: string
  /** Array of doc paths to show as popular/featured when search is empty */
  popularPaths?: string[]
}>()

const isModalOpen = ref(false)
const isMac = ref(false)

onMounted(() => {
  // Detect platform for keyboard shortcut display
  isMac.value = navigator.platform.toLowerCase().includes('mac')

  // Register global keyboard shortcut
  const handleGlobalKeydown = (event: KeyboardEvent) => {
    // Cmd+K on Mac, Ctrl+K on Windows/Linux
    if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
      event.preventDefault()
      isModalOpen.value = true
    }
  }

  document.addEventListener('keydown', handleGlobalKeydown)

  onUnmounted(() => {
    document.removeEventListener('keydown', handleGlobalKeydown)
  })
})

function openModal() {
  isModalOpen.value = true
}
</script>

<template>
  <div class="w-full">
    <!-- Search Trigger Button -->
    <Button
      ghost
      class="bg-base-100 border border-base-300 w-full justify-start gap-2 font-normal text-base-content/60 hover:text-base-content hover:bg-base-100 hover:border-base-content/20 whitespace-nowrap"
      @click="openModal"
    >
      <Icon name="heroicons:magnifying-glass" class="w-4 h-4" />
      <Text class="grow text-left">Search docs...</Text>
      <Kbd sm class="hidden sm:inline-flex">{{ isMac ? '⌘' : 'Ctrl' }}k</Kbd>
    </Button>

    <!-- Search Modal -->
    <DocsSearchModal
      v-model="isModalOpen"
      :collections="props.collections"
      :search-label="props.searchLabel"
      :popular-paths="props.popularPaths"
    />
  </div>
</template>
