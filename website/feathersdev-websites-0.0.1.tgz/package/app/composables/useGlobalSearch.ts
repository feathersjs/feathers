const isSearchOpen = ref(false)

export function useGlobalSearch() {
  function openSearch() {
    isSearchOpen.value = true
  }

  function closeSearch() {
    isSearchOpen.value = false
  }

  function toggleSearch() {
    isSearchOpen.value = !isSearchOpen.value
  }

  return {
    isSearchOpen,
    openSearch,
    closeSearch,
    toggleSearch,
  }
}
