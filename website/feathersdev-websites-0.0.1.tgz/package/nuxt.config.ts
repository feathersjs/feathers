import { fileURLToPath } from 'node:url'
import tailwindcss from '@tailwindcss/vite'

// https://nuxt.com/docs/guide/going-further/layers
export default defineNuxtConfig({
  modules: [
    '@nuxt/content',
    '@nuxt/eslint',
    '@nuxt/fonts',
    '@nuxt/icon',
    'daisy-ui-kit/nuxt',
    '@nuxt/image',
    '@nuxt/scripts',
    '@nuxt/test-utils',
    '@formkit/auto-animate/nuxt',
  ],

  devtools: { enabled: true },

  content: {
    build: {
      markdown: {
        highlight: {
          theme: {
            default: 'github-dark',
          },
          preload: ['json', 'js', 'ts', 'html', 'bash', 'tsx', 'svelte', 'vue'],
          langs: [
            'json',
            'js',
            'ts',
            'html',
            'css',
            'bash',
            'shell',
            'python',
            'go',
            'rust',
            'yaml',
            'markdown',
            'sql',
            'dockerfile',
            'nginx',
            'tsx',
            'svelte',
            'vue',
          ],
        },
      },
    },
    renderer: {
      anchorLinks: true,
    },
  },

  runtimeConfig: {
    public: {
      mdc: {
        headings: {
          anchorLinks: true,
        },
      },
    },
  },

  compatibilityDate: '2024-11-01',

  vite: {
    plugins: [tailwindcss()],
  },

  eslint: {
    config: {
      standalone: false,
      stylistic: {
        indent: 2,
        quotes: 'single',
        semi: false,
        jsx: true,
      },
    },
  },

  fonts: {
    defaults: {
      weights: [400, 500, 600, 700, 800, 900],
      styles: ['normal', 'italic'],
    },
  },

  icon: {
    serverBundle: {
      collections: ['feather', 'heroicons'],
    },
    customCollections: [
      {
        prefix: 'feathersdev',
        dir: fileURLToPath(new URL('./app/assets/icons', import.meta.url)),
      },
    ],
  },
})
